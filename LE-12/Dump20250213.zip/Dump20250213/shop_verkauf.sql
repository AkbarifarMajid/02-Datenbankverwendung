-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: shop
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `verkauf`
--

DROP TABLE IF EXISTS `verkauf`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verkauf` (
  `verkauf_id` int NOT NULL AUTO_INCREMENT,
  `kunden_id` int DEFAULT NULL,
  `datum` date NOT NULL,
  `betrag` decimal(10,2) NOT NULL,
  `status` enum('Offen','Bezahlt','Storniert') DEFAULT 'Offen',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`verkauf_id`),
  KEY `index_verkauf_datum` (`datum`),
  KEY `index_kunde_datum` (`kunden_id`,`datum`),
  CONSTRAINT `verkauf_ibfk_1` FOREIGN KEY (`kunden_id`) REFERENCES `kunden` (`kunden_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verkauf`
--

LOCK TABLES `verkauf` WRITE;
/*!40000 ALTER TABLE `verkauf` DISABLE KEYS */;
INSERT INTO `verkauf` VALUES (1,1,'2024-02-12',3.60,'Bezahlt','2025-02-11 19:06:33','2025-02-11 19:06:33'),(2,2,'2024-02-14',3.00,'Offen','2025-02-11 19:06:33','2025-02-11 19:06:33'),(4,1,'2024-02-18',10.50,'Offen','2025-02-12 08:04:03','2025-02-12 08:04:03'),(5,2,'2024-02-20',15.20,'Bezahlt','2025-02-12 08:04:03','2025-02-12 08:04:03'),(11,1,'2025-02-13',20.00,'Offen','2025-02-13 12:56:08','2025-02-13 12:56:08'),(12,8,'2025-02-13',52.75,'Offen','2025-02-13 13:12:27','2025-02-13 13:12:27');
/*!40000 ALTER TABLE `verkauf` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-13 16:17:35
